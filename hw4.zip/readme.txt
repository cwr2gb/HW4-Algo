Run program with:
 javac HW4.java
 java HW4 (input file here)